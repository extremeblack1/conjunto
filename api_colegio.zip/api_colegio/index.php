<?php
    //Configuración inicial
    ini_set("display_errors", 1);
    error_reporting(E_ALL);
    
    //Headers para CORS y tipos de contenido
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: content-Type, ngrok-skip-browser-warnin');

    #Manejo de preflight request
    if($_SERVER['REQUEST_METHOD'] === 'OPTIONS')
    {
        http_response_code(200);
        exit();
    }
    #Logging
    file_put_contents('debug.log', "Petición recibida: " .date('Y-m-d H:i:s'). 
    "\n", FILE_APPEND);
    
    #Respuesta por defecto
    $response = ['success' => false, 'message' => 'Invalid request'];
    
    try
    {
        #Leer y validar el input JSON
        $jsonInput = file_get_contents('php://input');
        file_put_contents('debug.log', "Datos recibidos (raw): " . $jsonInput ."\n", FILE_APPEND);
        $input = json_decode($jsonInput, true);

        #Validar el JSON
        if(json_last_error() !== JSON_ERROR_NONE)
        {
            throw new Exeption('JSON inválido: ' . json_last_error_msp());
        }

        file_put_contents('debug.log', "Datos decodificados: " .print_r($input, true . "\n" . FILE_APPEND));

    #Incluir el controlador
    require __DIR__.'/Controllers/AuthController.php';
        $controller = new AuthController();

        if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($input['action']))
        {
            switch($input['action'])
            {
                case 'register':
                    $required = [
                        'ID_Alumno' => isset($input['ID_Alumno']) ? $input['ID_Alumno'] : null,
                        'name' => isset($input['name']) ? $input['name'] : null,
                        'email' => isset($input['email']) ? $input['email'] : null,
                        'Clave' => isset($input['Clave']) ? $input['Clave'] : null,
                        'Grado' => isset($input['Grado']) ? $input['Grado'] : null,
                    ];

                    if(in_array(null, $required, true))
                    {
                        $missing = array_key($required, null, true);
                        $response = [
                            'success' => false,
                            'message' => "Campo requeridos faltantes: " . implode(', '.$missing)
                        ];
                    }
                    else
                    {
                        $responde = $controller->register(...array_values($required));
                    }
                    break;

                case 'login':
                    if(!isset($input['email'], $input['password']))
                    {
                        throw new Exception('Falta campos requeridos para el login\n');
                    }
                    $response = $controller->login(
                        $input['email'],
                        $input['password']
                    );
                    break;
                default:
                    $resonse['message'] = 'Acción no válida';
            }
        }
    }
    catch(Exception $e)
    {
        $response['success']= $e->getMessage();
        file_put_contents('debug.log', "Error:" . $e->getMessage(). "\n", FILE_APPEND);
    }
        
        //Asegurar que la respuesta sea válida
    if(!isset($response['mesage']))
    {
        $response['success'] = false;
        if(!isset($response['success']))
        {
            if(!isset($responde['meesage']))
            {
                $response['message'] = 'Respuesta inválida del controlador';
            }
        }
    }

#Devuelve la respuesta como JSON
echo json_encode($response);
?>