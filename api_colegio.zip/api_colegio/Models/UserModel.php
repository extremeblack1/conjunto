<?php
    class UserModel
    {
        private $conn;

        public function __construct($db)
        {
            $this ->conn = $db;
        }

        //Registrar usuario
        public function register($ID_A, $name, $email, $password, $grade)
        {
            //Verificar si el usuario ya existe
            $query = 'SELECT * FROM Colegio WHERE ID_Alumno = ?  OR Correo = ? 
                LIMIT 1';
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$ID_A, $email]);
            if($stmt->rowCount() > 0)
            {
                return false;
            }

            //Insertar nuevo usuario
            $query = "INSERT INTO Colegio (ID_Alumno, Nombre, Correo, Clave, Grado)
                VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$ID_A, $name, $email, $password, $grade]);
        }
        //Login de usuario
        public function login($email, $password)
        {
            file_put_contents('debug.log', "Intentando login para: $email\n", 
            FILE_APPEND);
            
            //Verificar si el usuario existe
            $query = 'SELECT ID_Alumno, Nombre FROM Colegio WHERE ID_Alumno = ? AND Correo = ?
                LIMIT 1';
            $stmt->execute([$email, $password]);

            file_put_contents('debug.log', "Consulta ejecutadas. Filas: " . 
            $stmt->rowCount()."\n", FILE_APPEND);

            //Si el usuario existe, devuelve el nombre
            if($stmt->rowCount() > 0)
            {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                file_put_contents('debug.log', "Datos del usuario: " .print_r($row, 
                    true)."\n", FILE_APPEND);

                //Devuelve un array con todos los datos necesarios
                return [
                    'id' => $row["ID_Alumno"],
                    'name' => (string)($row["Nombre"] ?? ''),
                ];
            }
            return false;
        }
    }
?>