<?php
    class AuthController
    {
        private $db;
        private $user;

        public function __construct()
        {
            require_once __DIR__ . '/../config/database_services.php';
            require_once __DIR__ . '/../Models/UserModel.php';
            require_once __DIR__ . '/../config.php';

            $database = new Database();
            $this->db = $database->getConnection();
            $this->user = new UserModel($this->db);
        }

        public function register($ID_A, $name, $email, $password, $grade)
        {
            $response = ["Success" => false];

            if($this->user->register($ID_A, $name, $email, $password, $grade))
            {
                $response['Success'] = true;
                $response['message'] = "Usuario registrado correctamente\n";
            }
            else
            {
                $response['message'] = "El usuario ya existe\n";
            }
            return $response;
        }

        public function login($email, $password)
        {
            #Inicializa la respuesta con todos los campos necesarios

            $response = [
                "success" => false,
                "message" => "",
                "name" => "",
                "ID_Alumno" => "",
            ];

            try
            {
                $userData = $this->user->login($email, $password);

                
                if($userData !== false && is_array($userData))
                {
                    $response["success"] = true;
                    $response["message"] = "login exitoso\n";
                    $response["nombre"] = $userData['name'] ?? '';
                    $response["ID_Alumno"] = $userData['ID_Alumno'] ?? 0;
                }
                else
                {
                    $response["message"] = "Credenciales incorrectas\n";
                }
            }
            catch(Exception $e)
            {
                $response["message"] = "Error en el servidor: " . $e->getMessage() . "\n";
            }
            return $response;
        }
    }
?>